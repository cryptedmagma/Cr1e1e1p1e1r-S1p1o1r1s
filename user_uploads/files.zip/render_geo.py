import json, math, glob, os, re, sys
import numpy as np
from PIL import Image, ImageDraw
SRC="/home/claude/Cr1e1e1p1e1r-S1p1o1r1s/Creeper_Spores_0.8.30/source/resource_pack/"
def rot(r):
    rx,ry,rz=[math.radians(a) for a in r]
    X=np.array([[1,0,0],[0,math.cos(rx),-math.sin(rx)],[0,math.sin(rx),math.cos(rx)]])
    Y=np.array([[math.cos(ry),0,math.sin(ry)],[0,1,0],[-math.sin(ry),0,math.cos(ry)]])
    Z=np.array([[math.cos(rz),-math.sin(rz),0],[math.sin(rz),math.cos(rz),0],[0,0,1]])
    return Z@Y@X
def faces_of(c):
    o=np.array(c["origin"],float); s=np.array(c["size"],float); inf=c.get("inflate",0)
    o=o-inf; s=s+2*inf
    x0,y0,z0=o; x1,y1,z1=o+s
    sx,sy,sz=s
    return {
     "north":((x1,y1,z0),(-1,0,0),(0,-1,0),sx,sy),
     "south":((x0,y1,z1),(1,0,0),(0,-1,0),sx,sy),
     "east": ((x1,y1,z1),(0,0,-1),(0,-1,0),sz,sy),
     "west": ((x0,y1,z0),(0,0,1),(0,-1,0),sz,sy),
     "up":   ((x1,y1,z1),(-1,0,0),(0,0,-1),sx,sz),
     "down": ((x1,y0,z0),(-1,0,0),(0,0,1),sx,sz)}
def uvrect(c,face,w,h):
    uv=c.get("uv"); s=c["size"]; sx,sy,sz=s
    if isinstance(uv,dict):
        f=uv.get(face)
        if not f: return None
        return f["uv"],f.get("uv_size",[w,h])
    u,v=uv
    m={"up":(u+sz,v,sx,sz),"down":(u+sz+sx,v,sx,sz),"east":(u,v+sz,sz,sy),"north":(u+sz,v+sz,sx,sy),
       "west":(u+sz+sx,v+sz,sz,sy),"south":(u+2*sz+sx,v+sz,sx,sy)}[face]
    return [m[0],m[1]],[m[2],m[3]]
def collect(geo):
    d=geo["minecraft:geometry"][0]; bones={b["name"]:b for b in d["bones"]}
    def chain(b):
        out=[]
        while b: out.append(b); b=bones.get(b.get("parent"))
        return out
    tris=[]
    for b in d["bones"]:
        for c in b.get("cubes",[]):
            tris.append((c,chain(b)))
    return d["description"],tris
def render(name,tex,yaw=32,pitch=22,S=7,size=(360,360)):
    geo=json.load(open(SRC+f"models/entity/{name}.geo.json"))
    desc,cubes=collect(geo)
    tw,th=desc.get("texture_width",64),desc.get("texture_height",32)
    T=tex.convert("RGBA"); 
    if T.size!=(tw,th): T=T.resize((tw,th),Image.NEAREST)
    arr=np.array(T)
    quads=[]
    cy,sy_=math.cos(math.radians(yaw)),math.sin(math.radians(yaw))
    cp,sp=math.cos(math.radians(pitch)),math.sin(math.radians(pitch))
    Ry=np.array([[cy,0,sy_],[0,1,0],[-sy_,0,cy]]); Rx=np.array([[1,0,0],[0,cp,-sp],[0,sp,cp]])
    V=Rx@Ry
    def xf(p,c,chain):
        p=np.array(p,float)
        if "rotation" in c:
            pv=np.array(c.get("pivot",[0,0,0]),float); p=rot(c["rotation"])@(p-pv)+pv
        for b in chain:
            if "rotation" in b:
                pv=np.array(b.get("pivot",[0,0,0]),float); p=rot(b["rotation"])@(p-pv)+pv
        return p
    for c,chain in cubes:
        fs=faces_of(c)
        for fn,(org,ud,vd,w,h) in fs.items():
            r=uvrect(c,fn,w,h)
            if not r: continue
            (u0,v0),(uw,vh)=r
            if c.get("mirror") and not isinstance(c.get("uv"),dict): pass
            nx,ny=int(round(uw)),int(round(vh))
            if nx<=0 or ny<=0: continue
            org=np.array(org,float); ud=np.array(ud,float); vd=np.array(vd,float)
            for j in range(ny):
                for i in range(nx):
                    px=int(u0)+i; py=int(v0)+j
                    if not(0<=px<tw and 0<=py<th): continue
                    col=arr[py,px]
                    if col[3]<20: continue
                    a=org+ud*(i*w/nx)+vd*(j*h/ny); b=org+ud*((i+1)*w/nx)+vd*(j*h/ny)
                    cc=org+ud*((i+1)*w/nx)+vd*((j+1)*h/ny); d=org+ud*(i*w/nx)+vd*((j+1)*h/ny)
                    P=[V@xf(q,c,chain) for q in (a,b,cc,d)]
                    z=sum(q[2] for q in P)/4
                    # simple face-normal shading
                    sh={"up":1.0,"north":0.85,"south":0.7,"east":0.78,"west":0.78,"down":0.55}[fn]
                    quads.append((z,P,tuple(int(min(255,v*sh)) for v in col[:3])))
    quads.sort(key=lambda q:-q[0])
    img=Image.new("RGB",size,(40,40,52)); dr=ImageDraw.Draw(img)
    ox,oy=size[0]/2,size[1]*0.82
    for z,P,col in quads:
        pts=[(ox+q[0]*S,oy-(q[1]-0)*S*-1*-1) for q in P]
        pts=[(ox+q[0]*S, oy-q[1]*S) for q in P]
        dr.polygon(pts,fill=col)
    return img
if __name__=="__main__":
    names=sorted(os.path.basename(f)[:-9] for f in glob.glob(SRC+"models/entity/*_creeper.geo.json"))
    print(names)
