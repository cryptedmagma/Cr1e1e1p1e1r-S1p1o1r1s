# Creeper Spores 0.8.30 - look-match review

Method: an offline renderer (render_geo.py) draws each of the 23 `.geo.json` models with its
real 128x128 texture from the repo, next to the supplied reference art. It is an approximation
of Bedrock rendering (rotation order and shading are my assumptions), so treat every item below
as "check in game", not as a confirmed bug.

## What already matches
- Texture palettes: all 23 repo textures already use the reference colours.
- Signature parts are present in the models: moss crown, cave spikes, crystal clusters, lily pad
  head, cactus/branches, ice cap, jungle leaves, mushroom cap, sculk/nether horns, end horns,
  water/bubble pieces, thorn spikes, phantom wings, spore queen cap, grass hat, stacked wood faces.

## Candidates to verify in Minecraft (largest visual gaps first)
1. Proportions: the references show chunky bodies on four stubby feet. Most models render slimmer
   (standard creeper body). Giant Creeper differs most: the art has a very large head/body.
2. Lava Creeper: art is a dark maroon body with orange cracks; the render reads much more
   orange/yellow. Check the default and alt textures in game before changing anything.
3. Per-creeper detail pieces (flowers, glow motes, particles, bubbles) are small cubes or
   particles in the models; in the render they are thinner/sparser than in the art.
4. No emissive/glow material is used anywhere. Lava, Glowing, Crystal, Sculk, Nether and
   Water would glow in the art. Doing this needs a Bedrock emissive material plus alpha-marked
   textures and cannot be verified without running Minecraft.

## Not done, and why
- Nothing in the repo was modified or pushed (no write access; cloned read-only).
- The earlier creeper_textures.zip (64x32 skins) is NOT compatible with these models (128x128
  custom UVs) and should not be merged.
- Checklist items 3-7, 9, 12 and the 18 in-game tests need a Bedrock runtime.
- Baseline: test_0_8_30.py passes 1,379 offline checks, unchanged.
